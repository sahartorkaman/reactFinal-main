# Android Keystore Credentials

These credentials are used in conjunction with your Android keystore file to sign your app for distribution. 

## Credential Values

- Android keystore password: e9e5a428be074832a9b7dec8a7524114
- Android key alias: QHNhaGFydHJlL2F6YWRqYQ==
- Android key password: 9198c7ba3161426f9ad065345db5a2df
      